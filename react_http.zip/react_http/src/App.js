import logo from './logo.svg';
import './App.css';
import PostList from './components/PostList';
import PostForm from './components/PostForm';

function App() {
  return (
    <div className="App">
     <h3>Welcome to Http Library - AXIOS</h3>
     <PostList />
     <PostForm />
    </div>
  );
}

export default App;
