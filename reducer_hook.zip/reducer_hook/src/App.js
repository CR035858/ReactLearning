import logo from './logo.svg';
import './App.css';
import CounterOne from './components/CounterOne';

function App() {
  return (
    <div className="App">
     <CounterOne />
    </div>
  );
}

export default App;
