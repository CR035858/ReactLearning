import React , { Component }  from "react";
import UpdatedComponent1 from "./withCounterNew";
class HoverCounterLatest extends Component{
    
    render() {
        const {count,incrementCount} = this.props
        return <h2 onMouseOver={incrementCount}> Hovered {count} times</h2>
    }
}
export default UpdatedComponent1(HoverCounterLatest,10)