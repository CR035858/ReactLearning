import React from 'react'
const  UpdatedComponent1 = (OriginalComponent,incrementNumber) => {
    
   class NewComponent1 extends React.Component{
    constructor(props) {
        super(props)     
        this.state = {
           count : 0
        }
    }
  
      incrementCount = () =>{
        
          this.setState(prevState => {
              return {count : prevState.count + incrementNumber}
          })
      }

       render () {
            console.log(" City ",this.props.city)
           return <OriginalComponent count = {this.state.count} incrementCount = {this.incrementCount} { ... this.props} />
       }
   }
   return NewComponent1
   }
   export default UpdatedComponent1