import React, { Component } from 'react'
import UpdatedComponent1 from './withCounterNew'
 class ClickCounterNew extends Component {
     /* REDUNDANT CODE TRANSFERRED TO HOC 
     constructor(props) {
      super(props)
    
      this.state = {
         count : 0
      }
    }

    incrementCount = () =>{
        this.setState(prevState => {
            return {count : prevState.count + 1}
        })
    } */
    
  render() {
    const {count, incrementCount, city} = this.props
    //const count = this.state.count
    return <button onClick= {incrementCount}>  Clicked {count} times in {city} </button>
  }
}

export default UpdatedComponent1(ClickCounterNew,5)