import logo from './logo.svg';
import './App.css';
import ClickCounter from './components/ClickCounter';
import HoverCounter from './components/HoverCounter';
import ClickCounterNew from './components/ClickCounterNew';
import HoverCounterNew from './components/HoverCounterNew';
import HoverCounterLatest from './components/HoverCounterLatest';
import ClickCounterTwo from './components/ClickCounterTwo';
import HoverCounterTwo from './components/HoverCounterTwo';
import User from './components/User';
import Counter from './components/Counter';
function App() {
  return (
    <div className="App">
      <h3>Welcome to Higher Order Components!!!</h3>
     {/* 
      <ClickCounter />
      <HoverCounter />  
    
      <ClickCounterNew city="Bangalore"/>
      <HoverCounterNew /> 
      <HoverCounterLatest /> */}
     {/* <ClickCounterTwo />
      <HoverCounterTwo /> */} 
      
      <Counter render = { (count,incrementCount) =>(
        <ClickCounterTwo count ={count} incrementCount={incrementCount} />
      ) } />

    <Counter render = { (count,incrementCount) =>(
        <HoverCounterTwo count ={count} incrementCount={incrementCount} />
      ) } />
       
      <User render={ (isLoggedIn) => isLoggedIn ? 'GreatLearning!!!' : 'Other Ed Techs'}/>
    </div>
  );
}

export default App;
