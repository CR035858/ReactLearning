import logo from './logo.svg';
import './App.css';
import RefsDemo from './components/RefsDemo';
import FocusInput from './components/FocusInput';
import FRParentInput from './components/FRParentInput';
import Hero from './components/Hero';
import PortalDemo from './components/PortalDemo';
import PortalDemo1 from './components/PortalDemo1';
import ErrorBoundary from './components/ErrorBoundary';

function App() {
  return (
    <div className="App">
      {/*  <PortalDemo />
      <PortalDemo1 /> */}
      <ErrorBoundary>
        <Hero heroName='BatMan' />
      </ErrorBoundary>
      <ErrorBoundary>
        <Hero heroName='SuperMan' /> 
      </ErrorBoundary>
      <ErrorBoundary>
        <Hero heroName='Joker' /> 
      </ErrorBoundary>
     {/* <FRParentInput /> */}
      {/* <RefsDemo /> 
      <FocusInput /> */}
      <h2>Welcome </h2>
    </div>
  );
}

export default App;
