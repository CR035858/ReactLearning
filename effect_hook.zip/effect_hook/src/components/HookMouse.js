import React, {useState,useEffect} from 'react'

function HookMouse() {
    const [x,setX] = useState(0)
    const [y,setY] = useState(0)

    const logMousePosition = e => {
        console.log('Mouse Event')
        setX(e.clientX)
        setY(e.clientY)
    }
    /* useEffect invoked for Every Eender
    useEffect(() =>{
        console.log('use Effect Called')
        window.addEventListener('mousemove',logMousePosition)
    }*/
   /* useEffect invoked not based on condition as in prev example
   But ONLY ONCE */
    useEffect(() =>{
        console.log('use Effect Called')
        window.addEventListener('mousemove',logMousePosition)
      /*
      Whenever CleanUp activity is to be done as shown below
      that can be done by a return function, within the useEffect function
      which in ClassComponenent would be done in  componentWillUnmount() method
      */
        return() => {
          console.log('Component UnMounting')
          window.removeEventListener('mousemove',logMousePosition)
        }
    },[])
  return (
    <div>
       X - {x} Y - {y}
    </div>
  )
}

export default HookMouse
