import React,{useState,useEffect} from 'react'

function HookCounterOne() {
    const [count, setCount] = useState(0)
    const [name,setName] = useState('')

  /* Without Conditional useEffect*/
   /* useEffect(() => {
        document.title = `You Clicked ${count} times`
    }) */
// With Conditional UseEffect
    useEffect(() => {
      console.log('Use Effect - Updating Document Tile')
      document.title = `You Clicked ${count} times`
  },[count])
  /*
  As we know useEffect is called for every render
  here above it checks the elements value in the array - i.e count
  if it has changed then only it 
  */
  return (
    <div>
      <input type="text" value={name} onChange={e => setName(e.target.value)} />
      <button onClick={() => setCount(count + 1)}>Clicked {count} times</button>
    </div>
  )
}

export default HookCounterOne
