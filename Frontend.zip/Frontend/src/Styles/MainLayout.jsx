
import styled from 'styled-components'

export const MainLayout = styled.div`
        padding:1rem;
        height:100vh;
        display:flex;
        gap:1rem;
        background-color: #444644;
        /* background: rgb(255, 255, 255); */
`