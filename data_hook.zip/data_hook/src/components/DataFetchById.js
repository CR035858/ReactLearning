import React,{useEffect,useState} from 'react'
import axios from 'axios'

function DataFetchById() {

    const [posts,setPosts] = useState([])
    const [id,setId] = useState(1)
    const [errorMsg,setErrorMsg] = useState()
    const [idFromButtonClick,setIdFromButtonClick] = useState(1)
    const handleClick = ()=>{
        setIdFromButtonClick(id)
    }
    useEffect(() => {
        /* axios.get('https://jsonplaceholder.typicode.com/posts')*/
        axios.get(`http://localhost:8080/students/allStudents/${idFromButtonClick}`)
        .then(response =>{
            console.log(response)
            setPosts(response.data)
        })
        .catch(error =>{
            console.log(error)
          setErrorMsg( 'Error Retrieving Data')
        },[idFromButtonClick])
    })

  return (
    <div>
      <input type="text" value={id} onChange={e => setId(e.target.value)} />
      <button type="button" onClick={handleClick}>Fetch Data</button>
      <div>{posts.firstName} {posts.lastName} {posts.marks}</div>
    </div>
  )
}

export default DataFetchById
