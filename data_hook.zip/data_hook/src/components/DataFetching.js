import React,{useEffect,useState} from 'react'
import axios from 'axios'
function DataFetching() {
    const [posts,setPosts] = useState([])
    const [errorMsg,setErrorMsg] = useState()

    useEffect(() => {
        /* axios.get('https://jsonplaceholder.typicode.com/posts')*/
        axios.get('http://localhost:8080/students/allStudents')
        .then(response =>{
            console.log(response)
            setPosts(response.data)
        })
        .catch(error =>{
            console.log(error)
          setErrorMsg( 'Error Retrieving Data')
        })
    })
  return (
    <div>
      <ul>
      <h3>List Of Posts...</h3>
        {
            posts.length ?
            posts.map(post => <div key={post.rollNo}>{post.firstName} {post.lastName} {post.marks}</div>) :
            null
        }
        {
            errorMsg ? <div>{errorMsg} </div> : null
        }
      </ul>
    </div>
  )
}

export default DataFetching
