import logo from './logo.svg';
import React from 'react'
import './App.css';
import DataFetching from './components/DataFetching';
import DataFetchById from './components/DataFetchById';
import ComponentC from './components/ComponentC';
export const UserContext = React.createContext()
export const ChannelContext = React.createContext()
function App() {
 return (
    <div className="App">
      <h2>Welcome to Service Data Page</h2>
     {/*  <DataFetching /> */}
     {/* <DataFetchById /> */} 
     <UserContext.Provider value={'Great Learning'}>
      <ChannelContext.Provider value={'Great Lakes'}>
          <ComponentC />
     </ChannelContext.Provider>
     </UserContext.Provider>
    </div>
  );
}

export default App;
