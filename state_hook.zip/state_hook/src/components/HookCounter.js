import React ,{useState} from 'react'
/* We are simulating the ClassCounter component through function component
 i.e Here, Instead of using a Class Based Component
function component is used,In a function component "state" cannot be implemented
hence we use "useState" Hook which does both activities of
a) Creating a State 
b) Invoking a function to operate upon the state variable
    */

function HookCounter() {
    /* state variable name -  count the handler function - setCount */
    const [count,setCount] = useState(0)
  return (
    <div>
      <button onClick={() => setCount(count + 1)}>Count {count}</button>
    </div>
  )
}

export default HookCounter
