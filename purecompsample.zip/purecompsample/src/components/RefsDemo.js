import React, { Component } from 'react'

class RefsDemo extends Component {
  render() {
    return (
      <div>
        <input type="text" />
      </div>
    )
  }
}

export default RefsDemo
